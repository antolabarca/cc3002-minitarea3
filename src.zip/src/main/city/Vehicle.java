package main.city;

public abstract class Vehicle implements Item{
    protected int year;

    /**
     * Returns this vehicles year
     */
    public int getYear() {return year;}

}
